#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<unistd.h>
#include<semaphore.h>
#include<queue>
#include<string.h>

#define VANILLA 1
#define CHOCOLATE 2
#define type_c 10
#define type_v 10

using namespace std;

class node
{
	public:
	int cake_type;
	int number;
	
	node(int a,int b)
	{
		cake_type=a;
		number=b;
	}
};

//semaphore to control sleep and wake up
sem_t empty1,empty2,empty3;
sem_t full1,full2,full3;
//queue<int> q1;
//queue<int> q2;
//queue<int> q3;

queue<node> q1;
queue<node> q2;
queue<node> q3;

pthread_mutex_t Console_lock;
pthread_mutex_t Vanilla_lock;
pthread_mutex_t Chocolate_lock;
pthread_mutex_t cake_lock;


void init_semaphore()
{
	sem_init(&empty1,0,5);
	sem_init(&empty2,0,5);
	sem_init(&empty3,0,5);
	sem_init(&full1,0,0);
	sem_init(&full2,0,0);
	sem_init(&full3,0,0);
	pthread_mutex_init(&Console_lock,0);
	pthread_mutex_init(&Vanilla_lock,0);
	pthread_mutex_init(&Chocolate_lock,0);
	pthread_mutex_init(&cake_lock,0);
}
void * Bake(void * arg)
{
	char* baker=(char*)arg;
	pthread_mutex_lock(&Console_lock);
	printf("Hi I am %s\n",baker);
	pthread_mutex_unlock(&Console_lock);
	if (strncmp(baker, "chefY", 5) == 0)
	{	

		for(int i=0;;i++)
		{
			sleep(1);
			sem_wait(&empty1);
		
			pthread_mutex_lock(&Console_lock);
			printf("Chef Y producing %d number vanilla cake and putting it into queue 1.\n",i+1);
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&cake_lock);
			node n=node(VANILLA,i+1);
			q1.push(n);
			pthread_mutex_unlock(&cake_lock);
			
			sem_post(&full1);
			
		}
	}
	else if(strncmp(baker, "chefX", 5) == 0)
	{	
		for(int i=0;;i++)
		{
			sleep(1);
			sem_wait(&empty1);
		
			pthread_mutex_lock(&Console_lock);
			printf("Chef X producing %d number chocolate cake and putting it into queue 1.\n",i+1);
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&cake_lock);
			node n=node(CHOCOLATE,i+1);
			q1.push(n);
			pthread_mutex_unlock(&cake_lock);

			
			sem_post(&full1);
			
		}
	}


}



void * Decorate(void * arg)
{
	pthread_mutex_lock(&Console_lock);
	printf("%s\n",(char*)arg);
	pthread_mutex_unlock(&Console_lock);
	for(int i=0;;i++)
	{
		sem_wait(&full1);
	
		pthread_mutex_lock(&Console_lock);
		printf("Chef Z picking up a cake from queue 1 for decorating.\n");
		pthread_mutex_unlock(&Console_lock);
		
		
		pthread_mutex_lock(&cake_lock);
		node n=q1.front();
		q1.pop();
		pthread_mutex_unlock(&cake_lock);
		
		if(n.cake_type==CHOCOLATE)
		{
			pthread_mutex_lock(&Console_lock);
			printf("Chef Z picked up %d number chocolate cake for decorating.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
		}
		else if(n.cake_type==VANILLA)
		{
			pthread_mutex_lock(&Console_lock);
			printf("Chef Z picked up %d number vanilla cake for decorating.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
		}
		
		sem_post(&empty1);
		//sleep(1);
		if(n.cake_type==CHOCOLATE)
		{

			
			sem_wait(&empty3);
			
			pthread_mutex_lock(&Console_lock);
			printf("Chef Z decorating %d number chocolate cake and putting it into queue 3.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&Chocolate_lock);
			q3.push(n);
			pthread_mutex_unlock(&Chocolate_lock);
			
			sem_post(&full3);
			sleep(15);
		}
		else if(n.cake_type==VANILLA)
		{

			sem_wait(&empty2);
			
			pthread_mutex_lock(&Console_lock);
			printf("Chef Z decorating %d number vanilla cake and putting it into queue 2.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&Vanilla_lock);
			q2.push(n);
			pthread_mutex_unlock(&Vanilla_lock);
		
			sem_post(&full2);
			sleep(15);
		}
		
		
	}
	
}
void* Serve(void * arg)
{
	char* waiter=(char*)arg;
	pthread_mutex_lock(&Console_lock);
	printf("Hi I am %s\n",waiter);
	pthread_mutex_unlock(&Console_lock);
	if (strncmp(waiter, "waiter1", 7) == 0)
	{	
		for(int i=0;;i++)
		{
			sleep(1);
			sem_wait(&full3);

			pthread_mutex_lock(&Console_lock);
			printf("Waiter 1 taking a chocolate cake from queue 3.\n");
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&Chocolate_lock);
			node n=q3.front();
			q3.pop();
			pthread_mutex_unlock(&Chocolate_lock);
			
						
			pthread_mutex_lock(&Console_lock);
			printf("Waiter 1 serving %d number chocolate cake.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
			
			sem_post(&empty3);
		}
			
	}
	else if(strncmp(waiter, "waiter2", 7) == 0)
	{
		for(int i=0;;i++)
		{
			sleep(1);
			sem_wait(&full2);

			pthread_mutex_lock(&Console_lock);
			printf("Waiter 2 taking a vanilla cake from queue 2.\n");
			pthread_mutex_unlock(&Console_lock);
			
			pthread_mutex_lock(&Vanilla_lock);

			node n=q2.front();
			q2.pop();
			pthread_mutex_unlock(&Vanilla_lock);
						
			pthread_mutex_lock(&Console_lock);
			printf("Waiter 2 serving %d number vanilla cake.\n",n.number);
			pthread_mutex_unlock(&Console_lock);
			
			sem_post(&empty2);
		}
	}
	
}

int main()
{
	pthread_t chefX;
	pthread_t chefY;
	pthread_t chefZ;
	pthread_t waiter1;
	pthread_t waiter2;
	
	init_semaphore();
	
	char  message1[] = "chefX";
	char  message2[] = "chefY";
	char  message3[] = "HI I AM CHEF Z";
	char  message4[] = "waiter1";
	char  message5[] = "waiter2";
	
	
	//pthread_create(&chefX,NULL,BakeChocolate,(void*)message1);
	//pthread_create(&chefY,NULL,BakeVanilla,(void*)message2);
	//pthread_create(&waiter1,NULL,ServeChocolateCake,(void*)message4);
	//pthread_create(&waiter2,NULL,ServeVanillaCake,(void*)message5);
	pthread_create(&chefX,NULL,Bake,(void*)message1);
	pthread_create(&chefY,NULL,Bake,(void*)message2);
	pthread_create(&chefZ,NULL,Decorate,(void*)message3);
	pthread_create(&waiter1,NULL,Serve,(void*)message4);
	pthread_create(&waiter1,NULL,Serve,(void*)message5);
	
	pthread_exit(NULL);
	return 0;
	
	
}



